// TO DO: Implementation of Instagram340 functions
#include <iostream>
#include <string>
#include "Instagram340.h"
// #include "LinkedBagDS/LinkedBag.h"

Instagram340::Instagram340(){

}

Instagram340::~Instagram340(){
	Instagram340::users.clear();
}

void Instagram340::createUser(const std::string& _username, const std::string& _email, const std::string& _password,
				const std::string& _bio, const std::string& _profilePicture){
					User newUser(_username, _email, _password, _bio, _profilePicture);
					users.add(newUser);
					// users.add(User(username, email, password, bio, profilePicture));
	// TO DO: implement function

}
void Instagram340::createUser(const User& newUser){
	users.add(newUser);

}

User Instagram340::getUser(const int& indexK){
	// TO DO: implement function
	Node<User>* userNode = users.findKthItem(indexK); //users.findKthItem(indexK);
	if(userNode != nullptr) {
		return userNode->getItem();
	}
	else {
		throw std::out_of_range("out of range");
	}
	// return userNode->getItem();
}