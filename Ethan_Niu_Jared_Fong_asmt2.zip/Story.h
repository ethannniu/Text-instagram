#include "Post.h"
#ifndef STORY__
#define STORY__

class Story: public Post {
    private:
    int computeTimeToExpiration() const;
    std::chrono::_V2::steady_clock::time_point _time_stamp;

    public:

    Story();
    Story(std::string& title,std::string& URL, int duration);

    bool createReel();
    void displayPost() override;
    bool editPost();
    bool changeTitle(std::string title);
};
#endif