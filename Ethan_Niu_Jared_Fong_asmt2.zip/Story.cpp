#include "Story.h"
#include "Post.h"
Story::Story(){};

Story::Story(std::string& title,std::string& URL, int duration) {
	_duration = duration;
    std::chrono::steady_clock::time_point _timestamp = std::chrono::steady_clock::now();

	_likes = 0;
	_title = title;
	_URL = URL;


}
void Story::displayPost() {
    std::cout << "STORY"<<std:: endl;
	std::cout << "Title: " << _title << std::endl;
    std::cout<< "Duration: " << _duration <<std::endl;
	std::cout << "likes: " << _likes << std::endl;
	std::cout << "URL: " << _URL << std::endl;
    int time = computeTimeToExpiration();
    if(computeTimeToExpiration() < 0) {
        std::cout << "Story is expired";
    }else {
        std::cout << "Time left: " << time;
    }

}

bool Story::editPost() {
    std::cout << "Filter, music, stickers, and effects have been added";
    return true;
}

int Story::computeTimeToExpiration() const{//I DONT THINK THIS PROVIDED FUNCTION WORKS 
	const int secondsInHour = 3600;
	// 24 hours in seconds
	const int expiresAfter = 24 *3600; 

	// Get current time
    std::chrono::steady_clock::time_point time_now = std::chrono::steady_clock::now();

	// Compute elapsed time since post creation
	std::chrono::duration<double> elapsed_seconds = time_now - Story::_time_stamp;
	// time to expiration in hours

	int timeToExpiration = (expiresAfter - elapsed_seconds.count());

	return timeToExpiration;
}


bool Story::changeTitle(std::string title) {
    std::cout<<"CHANTITTLE" <<title;
	_title = title;
	return true;
}

