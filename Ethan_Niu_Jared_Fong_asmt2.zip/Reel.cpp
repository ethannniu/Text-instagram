#include "Reel.h"
#include "Post.h"
Reel::Reel(){};

Reel::Reel(const std::string& title, const std::string& URL, int duration) {
	_duration = duration;
	auto _time_stamp = std::chrono::steady_clock::now();
	_likes = 0;
	_title = title;
	_URL = URL;


}
void Reel::displayPost() {
    std::cout << "REEL\n";
	std::cout << "Title: " << _title<<std::endl;
    std::cout<< "Duration: " << _duration <<std::endl;
	std::cout << "likes: " << _likes << std::endl;
	std::cout << "URL: " << _URL << std::endl << std::endl;

}

bool Reel::changeTitle(std::string title) {
    std::cout<<"TITLE CHANGE" <<title;
	_title = title;
	return true;
}


bool Reel::editPost() {
    std::cout << "added filter, AR effects, and music";
    return true;
}