#ifndef INSTA360
#define INSTA360
// TO DO include necessary libraries
#include "User.h"
#include "LinkedBagDS/LinkedBag.h"

// This class only contains a list of users
// It should allow clients to add users and retrieve a user from the list

class Instagram340 {
	private:
		LinkedBag<User> users;

	public:
		Instagram340();
		~Instagram340();

		void createUser(const std::string& _username, const std::string& _email, const std::string& _password,
						const std::string& _bio, const std::string& _profilePicture);

		void createUser(const User& newUser);

		User getUser(const int& indexK);
};

#endif