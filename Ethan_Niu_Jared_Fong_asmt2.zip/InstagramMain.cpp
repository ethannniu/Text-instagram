#include <iostream> 
#include <string>

// TO DO: #include any other libraries you need
#include "Instagram340.h"
#include "LinkedBagDS/LinkedBag.h"
#include "User.h"
#include "Reel.h"
using namespace std;

// /** 
//  * 
//  * Displays the application's main menu
//  * pre create a new object of type User
//  * @param user object to interact with
//  * 
//  * */
void displayUserManu(User& user){
	int userChoice = 0;
	do {
		cout << "\n Hi, "<< user.getUsername() <<", what would you like to do:\n"
		<< "1. Display Profile\n"
		<< "2. Modify Password\n"
		<< "3. Create Post\n"
		<< "4. Display All Posts\n"
		<< "5. Display Kth Post\n"
		<< "6. Modify Post\n"
		<< "7. Edit Post\n"
		<< "8. Delete Post\n"
		<< "0. Logout\n"
		<< "Choice: ";
		cin >> userChoice;

		switch (userChoice) {
			case 1:{
				// TO DO: display user's profile information
				    user.displayProfile();
				break;
			}
			case 2: {
				// TO DO: ask for new password and update user's password
				std:string x; 
				cout << "Type your new password: "; 
				cin >> x; //user input
				user.changePassword(x);//changes password
				break;
			}
			case 3: {
				//Pick a type of post
				int pick = 0;
				cout << "Choose post type:\n"// choose between reel and Story
				<< "1. Reel\n"
				<< "2. Story\n";
				cin >> pick;

				if(pick == 1) {
					//create reel
					cout<<"creating reel\n";
					string title;
					cout<<"Title: \n";//ask for title
					cin >> title;

					string url;
					cout<<"URL: \n";//ask for url
					cin >> url;

					int dur;
					cout<<"Duration: \n";
					cin >> dur;// ask for duration
					cout <<  dur;

					if(dur > 90) {
						cout << "max Story duratoin is 90. Setting duration to 90";
						dur = 90;
					}

				
				
					user.addReel(new Reel(title, url, dur)); //add the post
					break;
				}
				else if(pick == 2){ //create story
					cout<<"creating story\n";
					string title;
					cout<<"Title: \n";//title , URL, duratoin
					cin >> title;

					string url;
					cout<<"URL: \n";
					cin >> url;

					int dur;
					cout<<"Duration: \n";
					cin >> dur;
					//create story
					if(dur > 60) {
						cout << "max Story duration is 60. Setting duration to 60";
						dur = 60;
					}

					

					user.addStory(new Story(title, url, dur));// add story
					std::cout<<"created story";

				}
				else{
					std::cout << "invalid";
				}
				// TO DO: ask user to choose between Reel and Story, ask them to input post details:
				//        (title, media URL, video length in seconds)
				//        Your program should set the time stamp to current time (code provided in Post.cpp) 
				// then create the post and add it to the user's posts
				break;
			}
			case 4:{
				user.displayPosts();
				break;
			}
			case 5: {
				int pick = 0;
				cout << "Choose Value K:\n";//ask usefor value
				cin >> pick;
				if(pick <= 0 ||pick > user.getPostCount()) {// check for outlier
					cout<<"error: Value to big.\n Posts:" << user.getPostCount();
				}
				else {
					Post* thepost = user.getKthPost(pick - 1); //gets the post and displays
					thepost->displayPost();
				}

			
				// TO DO: ask the user for a value k
				// Find the Kth post, if k > Linked Bag size, 
				//    return an error message that includes the size of the Linked Bag
				break;
			}
			case 6: {
				int pick = 0;
				cout << "Choose Value K:\n";
				cin >> pick;

				string title;

				if(pick < 1 ||pick > user.getPostCount()) {
					cout<<"error: Value to big.\n LinkedBag size:" << user.getPostCount(); // check if k is too big
				}
				else {
					cout <<"New Title: \n";//ask for new title
					cin >> title;
					Post* thepost = user.getKthPost(pick - 1);
					thepost->changeTitle(title);// changes titles
				}
				// TO DO: ask the user for the index of the post they want to modify and the new title
				// Find the post, then update the title. 
				// If index > Linked Bag size, 
				//   return an error message that includes the size of the Linked Bag
				break;
			}
			case 7: {
				int pick = 0;
				cout << "Choose Value K:\n"; //ask for k value
				cin >> pick;

				if(pick < 1 ||pick > user.getPostCount()) {
					cout<<"error: Value to big.\n LinkedBag size:" << user.getPostCount(); //check for outliser
				}
				else {
					Post* thepost = user.getKthPost(pick - 1);// get the kth post
					if (thepost != nullptr) {
           			 	std::cout << "Editing post..." << std::endl;
           				thepost->editPost(); //edits post
        			} else {
           				 std::cout << "Error: Post not found." << std::endl;
       				 }
				}
				break;
				//edit a post (using the video editing function described below): the user needs to specify
				// the index of the post they want to edit, and
			}

			case 8: {
				int pick = 0;
				cout << "Choose Value K:\n";
				cin >> pick;

				if(pick < 1 ||pick > user.getPostCount()) {
					cout<<"error: Value to big.\n LinkedBag size:" << user.getPostCount();//check for outlier
				}
				else {
					user.deletePost(pick - 1);//delete post at index
					// Post* thepost = user.getKthPost(pick - 1);
					// if (thepost != nullptr) {
           			//  	std::cout << "Editing post..." << std::endl;
           			// 	thepost->(); 
        			// } else {
           			// 	 std::cout << "Error: Post not found." << std::endl;
       				//  }
				}
				// TO DO: ask the user for the index of the post they want to delete 
				// Find the post, then remove it from the list. 
				// If index > LinkedBag size, 
				//    return an error message that includes the size of the Linked Bag
				break;
			}
			case 0: {
				cout << "Logging you out." << endl;
				break;
			}
			default:
				cout << "Invalid choice. Please try again." << endl;
		}

	} while (userChoice != 0);
}


int main(){
	// Instantiating the program using the default constructor
	// With this implementation, the application will only have one user
	Instagram340 instagram; 


	cout << "\n Welcome to Instagram340:" << endl;
	// TO DO: Ask the user to enter their information 
	//        Instantiate a new User object


	// call instagram createUser function 
	// replace /*...*/ with the right parameters
	string _username, _email, _password, _bio, _profilePicture;
	_username = "ethan";
	_email = "ethanniu2003@gmail.com";
	_password = "123123";
	_bio = "I love wlaing on the part";
	_profilePicture = "someurl/123";
	instagram.createUser(_username, _email, _password, _bio, _profilePicture);



	// Retrieve the user 
	User currentUser = instagram.getUser(0);
	displayUserManu(currentUser);
				
	return 0;
}